import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usePortfolio, key } from "@/lib/portfolio";
import { INDICATIONS, SYSTEMS, type Indication, type SystemCode } from "@/lib/indications";
import { cn } from "@/lib/utils";
import { Download, LogOut } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/")({
  component: AdminDashboard,
});

type AuthState = "loading" | "anon" | "not_admin" | "admin";

function useAdminAuth() {
  const [state, setState] = useState<AuthState>("loading");
  const navigate = useNavigate();
  useEffect(() => {
    let mounted = true;
    const check = async () => {
      const { data: s } = await supabase.auth.getSession();
      if (!s.session) { if (mounted) setState("anon"); return; }
      const { data: roles } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", s.session.user.id);
      if (!mounted) return;
      setState(roles?.some((r: any) => r.role === "admin") ? "admin" : "not_admin");
    };
    check();
    const { data: sub } = supabase.auth.onAuthStateChange(() => check());
    return () => { mounted = false; sub.subscription.unsubscribe(); };
  }, [navigate]);
  return state;
}

function AdminDashboard() {
  const auth = useAdminAuth();
  const navigate = useNavigate();
  const [indication, setIndication] = useState<Indication>(INDICATIONS[0]);
  const [systemFilter, setSystemFilter] = useState<"all" | SystemCode>("all");
  const [expFilter, setExpFilter] = useState<string>("all");

  useEffect(() => {
    if (auth === "anon") navigate({ to: "/admin/login" });
  }, [auth, navigate]);

  if (auth === "loading") return <CenterMsg>Checking access…</CenterMsg>;
  if (auth === "anon") return null;
  if (auth === "not_admin") return (
    <CenterMsg>
      You're signed in but don't have admin access. Ask another admin to grant your account the admin role.
      <div className="mt-4 flex justify-center gap-2">
        <Button variant="outline" size="sm" onClick={() => supabase.auth.signOut()}>Sign out</Button>
      </div>
    </CenterMsg>
  );

  return <Dashboard {...{ indication, setIndication, systemFilter, setSystemFilter, expFilter, setExpFilter }} />;
}

function CenterMsg({ children }: { children: React.ReactNode }) {
  return (
    <main className="min-h-screen bg-background">
      <div className="mx-auto flex min-h-screen max-w-md items-center justify-center px-6">
        <Card className="w-full p-8 text-center text-sm text-muted-foreground">{children}</Card>
      </div>
    </main>
  );
}

interface DashProps {
  indication: Indication;
  setIndication: (i: Indication) => void;
  systemFilter: "all" | SystemCode;
  setSystemFilter: (s: "all" | SystemCode) => void;
  expFilter: string;
  setExpFilter: (s: string) => void;
}

function Dashboard({ indication, setIndication, systemFilter, setSystemFilter, expFilter, setExpFilter }: DashProps) {
  const navigate = useNavigate();
  const portfolio = usePortfolio();

  const clinicians = useQuery({
    queryKey: ["admin", "clinicians"],
    queryFn: async () => {
      const { data, error } = await supabase.from("clinicians").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const selections = useQuery({
    queryKey: ["admin", "selections"],
    queryFn: async () => {
      const { data, error } = await supabase.from("implant_selections").select("*").limit(50000);
      if (error) throw error;
      return data ?? [];
    },
  });

  const suggestions = useQuery({
    queryKey: ["admin", "suggestions", indication],
    queryFn: async () => {
      const { data, error } = await supabase.from("suggested_dimensions").select("*").eq("indication", indication);
      if (error) throw error;
      return data ?? [];
    },
  });

  // Build filtered selections for current indication
  const expByClinician = useMemo(() => {
    const m: Record<string, string | null> = {};
    (clinicians.data ?? []).forEach((c: any) => { m[c.id] = c.years_of_experience; });
    return m;
  }, [clinicians.data]);

  const filteredForIndication = useMemo(() => {
    return (selections.data ?? []).filter((r: any) => {
      if (r.indication !== indication) return false;
      if (systemFilter !== "all" && r.implant_system !== systemFilter) return false;
      if (expFilter !== "all" && expByClinician[r.clinician_id] !== expFilter) return false;
      return true;
    });
  }, [selections.data, indication, systemFilter, expFilter, expByClinician]);

  const totalResponders = useMemo(() => {
    return new Set(filteredForIndication.map((r: any) => r.clinician_id)).size;
  }, [filteredForIndication]);

  const exportCsv = () => {
    const rows = [
      ["clinician_id", "full_name", "country", "years_of_experience", "indication", "implant_system", "diameter", "length", "preference", "created_at"],
    ];
    const cMap: Record<string, any> = {};
    (clinicians.data ?? []).forEach((c: any) => { cMap[c.id] = c; });
    (selections.data ?? []).forEach((s: any) => {
      const c = cMap[s.clinician_id] ?? {};
      rows.push([
        s.clinician_id, c.full_name ?? "", c.country ?? "", c.years_of_experience ?? "",
        s.indication, s.implant_system, String(s.diameter), String(s.length), s.preference, s.created_at,
      ]);
    });
    const csv = rows.map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `implant-selections-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    toast.success("Export ready");
  };

  return (
    <main className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div>
            <Link to="/" className="text-xs text-muted-foreground hover:underline">← Questionnaire</Link>
            <h1 className="text-xl font-semibold tracking-tight">Admin · Insights</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={exportCsv}>
              <Download className="mr-2 h-4 w-4" /> Export CSV
            </Button>
            <Button variant="ghost" size="sm" onClick={async () => { await supabase.auth.signOut(); navigate({ to: "/admin/login" }); }}>
              <LogOut className="mr-2 h-4 w-4" /> Sign out
            </Button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-6 py-8">
        <div className="grid gap-4 sm:grid-cols-3">
          <StatCard label="Total clinicians" value={clinicians.data?.length ?? 0} />
          <StatCard label="Total selections" value={selections.data?.length ?? 0} />
          <StatCard label={`Responders for "${indication}"`} value={totalResponders} />
        </div>

        <Card className="mt-6 p-5">
          <div className="flex flex-wrap items-end gap-4">
            <FilterField label="Indication">
              <Select value={indication} onValueChange={(v) => setIndication(v as Indication)}>
                <SelectTrigger className="w-64"><SelectValue /></SelectTrigger>
                <SelectContent>{INDICATIONS.map((i) => <SelectItem key={i} value={i}>{i}</SelectItem>)}</SelectContent>
              </Select>
            </FilterField>
            <FilterField label="System">
              <Select value={systemFilter} onValueChange={(v) => setSystemFilter(v as any)}>
                <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All systems</SelectItem>
                  {SYSTEMS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </FilterField>
            <FilterField label="Experience">
              <Select value={expFilter} onValueChange={setExpFilter}>
                <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="<2">&lt; 2 years</SelectItem>
                  <SelectItem value="2-5">2–5</SelectItem>
                  <SelectItem value="6-10">6–10</SelectItem>
                  <SelectItem value="11-20">11–20</SelectItem>
                  <SelectItem value="20+">20+</SelectItem>
                </SelectContent>
              </Select>
            </FilterField>
          </div>

          <div className="mt-6 grid gap-6 md:grid-cols-2">
            {SYSTEMS.filter((s) => systemFilter === "all" || s === systemFilter).map((s) => (
              <Heatmap key={s} system={s} rows={filteredForIndication.filter((r: any) => r.implant_system === s)} portfolio={portfolio.data?.[s]} />
            ))}
          </div>
        </Card>

        <Card className="mt-6 p-5">
          <h2 className="text-base font-semibold">Most selected configurations (current filters)</h2>
          <FrequencyTable rows={filteredForIndication} />
        </Card>

        <Card className="mt-6 p-5">
          <h2 className="text-base font-semibold">Suggested missing dimensions — {indication}</h2>
          {(suggestions.data ?? []).length === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">No suggestions yet.</p>
          ) : (
            <ul className="mt-3 space-y-2 text-sm">
              {suggestions.data!.map((s: any) => (
                <li key={s.id} className="rounded-md border bg-muted/30 px-3 py-2">{s.suggestion_text}</li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </main>
  );
}

function StatCard({ label, value }: { label: string; value: number | string }) {
  return (
    <Card className="p-5">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 text-3xl font-semibold tracking-tight">{value}</div>
    </Card>
  );
}

function FilterField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1 text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</div>
      {children}
    </div>
  );
}

function Heatmap({ system, rows, portfolio }: { system: SystemCode; rows: any[]; portfolio: any }) {
  if (!portfolio) return null;
  // Weighted count: regular=2, occasional=1, not_preferred=-1
  const score: Record<string, number> = {};
  const count: Record<string, number> = {};
  rows.forEach((r) => {
    const k = key(Number(r.diameter), Number(r.length));
    const w = r.preference === "regular" ? 2 : r.preference === "occasional" ? 1 : -1;
    score[k] = (score[k] ?? 0) + w;
    count[k] = (count[k] ?? 0) + 1;
  });
  const max = Math.max(1, ...Object.values(score));

  return (
    <div>
      <h3 className="mb-3 text-sm font-semibold">{system}</h3>
      <div className="overflow-x-auto">
        <table className="border-separate border-spacing-1">
          <thead>
            <tr>
              <th className="w-16 text-xs text-muted-foreground"></th>
              {portfolio.lengths.map((l: number) => (
                <th key={l} className="w-10 text-xs text-muted-foreground">{l}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {portfolio.diameters.map((d: number) => (
              <tr key={d}>
                <td className="text-xs font-medium pr-1">Ø {d}</td>
                {portfolio.lengths.map((l: number) => {
                  const disabled = !portfolio.valid.has(key(d, l));
                  const s = score[key(d, l)] ?? 0;
                  const c = count[key(d, l)] ?? 0;
                  const intensity = s > 0 ? s / max : 0;
                  return (
                    <td key={l}>
                      <div
                        title={`Ø${d} × ${l}: ${c} responses (score ${s})`}
                        className={cn(
                          "h-9 w-9 rounded text-[10px] flex items-center justify-center font-medium",
                          disabled ? "bg-[color:var(--pref-disabled)] text-transparent" :
                            c === 0 ? "bg-muted text-muted-foreground/60" : "text-primary-foreground",
                        )}
                        style={!disabled && c > 0 ? { backgroundColor: `oklch(0.42 0.14 255 / ${0.2 + intensity * 0.8})` } : undefined}
                      >
                        {disabled ? "" : c || ""}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function FrequencyTable({ rows }: { rows: any[] }) {
  const agg = useMemo(() => {
    const m: Record<string, { sys: string; d: number; l: number; reg: number; occ: number; not: number; total: number }> = {};
    rows.forEach((r) => {
      const k = `${r.implant_system}|${r.diameter}|${r.length}`;
      m[k] = m[k] ?? { sys: r.implant_system, d: Number(r.diameter), l: Number(r.length), reg: 0, occ: 0, not: 0, total: 0 };
      if (r.preference === "regular") m[k].reg++;
      else if (r.preference === "occasional") m[k].occ++;
      else m[k].not++;
      m[k].total = m[k].reg * 2 + m[k].occ - m[k].not;
    });
    return Object.values(m).sort((a, b) => b.total - a.total).slice(0, 15);
  }, [rows]);

  if (agg.length === 0) return <p className="mt-2 text-sm text-muted-foreground">No data for current filters.</p>;

  return (
    <div className="mt-3 overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-wider text-muted-foreground">
            <th className="py-2 pr-4">System</th><th className="py-2 pr-4">Ø</th><th className="py-2 pr-4">Length</th>
            <th className="py-2 pr-4">Regular</th><th className="py-2 pr-4">Occasional</th><th className="py-2 pr-4">Not preferred</th>
            <th className="py-2 pr-4">Score</th>
          </tr>
        </thead>
        <tbody>
          {agg.map((r) => (
            <tr key={`${r.sys}-${r.d}-${r.l}`} className="border-t">
              <td className="py-2 pr-4 font-medium">{r.sys}</td>
              <td className="py-2 pr-4">{r.d}</td>
              <td className="py-2 pr-4">{r.l} mm</td>
              <td className="py-2 pr-4 text-[color:var(--pref-regular)] font-medium">{r.reg}</td>
              <td className="py-2 pr-4">{r.occ}</td>
              <td className="py-2 pr-4 text-muted-foreground">{r.not}</td>
              <td className="py-2 pr-4 font-semibold">{r.total}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
