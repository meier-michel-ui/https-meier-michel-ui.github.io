import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuestionnaire } from "@/lib/questionnaire-store";
import { INDICATIONS, indicationSlug } from "@/lib/indications";
import { Stethoscope } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Implant Indication Selection Questionnaire" },
      { name: "description", content: "Clinician survey on Straumann implant preferences across dental indications." },
    ],
  }),
  component: Welcome,
});

function Welcome() {
  const navigate = useNavigate();
  const setClinician = useQuestionnaire((s) => s.setClinician);
  const reset = useQuestionnaire((s) => s.reset);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [country, setCountry] = useState("");
  const [years, setYears] = useState<string>("");
  const [err, setErr] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) { setErr("Please enter your full name."); return; }
    reset();
    setClinician({
      full_name: name.trim(),
      email: email.trim() || undefined,
      country: country.trim() || undefined,
      years_of_experience: years || undefined,
    });
    navigate({ to: "/questionnaire/$indication", params: { indication: indicationSlug(INDICATIONS[0]) } });
  };

  return (
    <main className="min-h-screen bg-background">
      <div className="mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-center px-6 py-12">
        <div className="mb-8 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Stethoscope className="h-5 w-5" />
          </div>
          <span className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
            Straumann Portfolio Study
          </span>
        </div>
        <h1 className="text-center text-4xl font-semibold tracking-tight text-foreground sm:text-5xl">
          Implant Indication Selection Questionnaire
        </h1>
        <p className="mt-4 max-w-xl text-center text-base text-muted-foreground">
          Please select which implant you would typically use for each clinical indication.
        </p>

        <Card className="mt-10 w-full p-8 shadow-[var(--shadow-soft)]">
          <form onSubmit={submit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name <span className="text-destructive">*</span></Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Dr. Jane Doe" required />
            </div>
            <div className="grid gap-5 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="email">Email <span className="text-muted-foreground">(optional)</span></Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@clinic.com" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="country">Country <span className="text-muted-foreground">(optional)</span></Label>
                <Input id="country" value={country} onChange={(e) => setCountry(e.target.value)} placeholder="Germany" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Years of Experience</Label>
              <Select value={years} onValueChange={setYears}>
                <SelectTrigger><SelectValue placeholder="Select range" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="<2">Less than 2 years</SelectItem>
                  <SelectItem value="2-5">2–5 years</SelectItem>
                  <SelectItem value="6-10">6–10 years</SelectItem>
                  <SelectItem value="11-20">11–20 years</SelectItem>
                  <SelectItem value="20+">20+ years</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {err && <p className="text-sm text-destructive">{err}</p>}
            <Button type="submit" className="w-full" size="lg">Start Questionnaire</Button>
          </form>
        </Card>

        <p className="mt-8 text-xs text-muted-foreground">
          8 indications · 4 implant systems · ~5 minutes
        </p>
      </div>
    </main>
  );
}
