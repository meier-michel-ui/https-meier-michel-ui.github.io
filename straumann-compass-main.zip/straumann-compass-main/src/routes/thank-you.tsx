import { createFileRoute, Link } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/thank-you")({
  component: () => (
    <main className="min-h-screen bg-background">
      <div className="mx-auto flex min-h-screen max-w-xl items-center justify-center px-6">
        <Card className="w-full p-10 text-center shadow-[var(--shadow-soft)]">
          <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary">
            <CheckCircle2 className="h-7 w-7" />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">Thank you</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            Your responses have been recorded. Your input helps shape future implant portfolio decisions.
          </p>
          <Button asChild className="mt-6"><Link to="/">Return to start</Link></Button>
        </Card>
      </div>
    </main>
  ),
});
