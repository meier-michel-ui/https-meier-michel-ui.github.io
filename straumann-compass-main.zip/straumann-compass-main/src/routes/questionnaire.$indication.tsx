import { createFileRoute, Navigate, useNavigate } from "@tanstack/react-router";
import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { INDICATIONS, indicationSlug, slugToIndication } from "@/lib/indications";
import { useQuestionnaire } from "@/lib/questionnaire-store";
import { PreferenceLegend, SystemMatrices } from "@/components/implant-matrix";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ArrowLeft, ArrowRight, Eraser, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/questionnaire/$indication")({
  component: IndicationPage,
});

function IndicationPage() {
  const { indication: slug } = Route.useParams();
  const navigate = useNavigate();
  const ind = slugToIndication(slug);
  const clinician = useQuestionnaire((s) => s.clinician);
  const selections = useQuestionnaire((s) => s.selections);
  const comments = useQuestionnaire((s) => s.comments);
  const suggestions = useQuestionnaire((s) => s.suggestions);
  const setComment = useQuestionnaire((s) => s.setComment);
  const setSuggestion = useQuestionnaire((s) => s.setSuggestion);
  const clearIndication = useQuestionnaire((s) => s.clearIndication);

  const idx = ind ? INDICATIONS.indexOf(ind) : -1;
  const isLast = idx === INDICATIONS.length - 1;

  const indicationsCovered = useMemo(() => {
    const set = new Set<string>();
    Object.keys(selections).forEach((k) => set.add(k.split("|")[0]));
    return set.size;
  }, [selections]);

  if (!clinician) return <Navigate to="/" />;
  if (!ind) return <Navigate to="/" />;

  const goNext = async () => {
    if (isLast) {
      await submitAll();
    } else {
      navigate({ to: "/questionnaire/$indication", params: { indication: indicationSlug(INDICATIONS[idx + 1]) } });
      window.scrollTo({ top: 0 });
    }
  };
  const goPrev = () => {
    if (idx > 0) {
      navigate({ to: "/questionnaire/$indication", params: { indication: indicationSlug(INDICATIONS[idx - 1]) } });
      window.scrollTo({ top: 0 });
    }
  };

  async function submitAll() {
    try {
      const state = useQuestionnaire.getState();
      const { data: cl, error } = await supabase
        .from("clinicians")
        .insert({
          full_name: state.clinician!.full_name,
          email: state.clinician!.email ?? null,
          country: state.clinician!.country ?? null,
          years_of_experience: state.clinician!.years_of_experience ?? null,
        })
        .select("id")
        .single();
      if (error || !cl) throw error;
      const clinicianId = cl.id;

      const selRows = Object.entries(state.selections).map(([k, preference]) => {
        const [indication, implant_system, d, l] = k.split("|");
        return {
          clinician_id: clinicianId,
          indication, implant_system,
          diameter: Number(d), length: Number(l), preference,
        };
      });
      if (selRows.length) {
        const { error: e } = await supabase.from("implant_selections").insert(selRows);
        if (e) throw e;
      }
      const comRows = Object.entries(state.comments)
        .filter(([, v]) => v.trim())
        .map(([indication, comment]) => ({ clinician_id: clinicianId, indication, comment }));
      if (comRows.length) await supabase.from("indication_comments").insert(comRows);

      const sugRows = Object.entries(state.suggestions)
        .filter(([, v]) => v.trim())
        .map(([indication, suggestion_text]) => ({ clinician_id: clinicianId, indication, suggestion_text }));
      if (sugRows.length) await supabase.from("suggested_dimensions").insert(sugRows);

      state.reset();
      navigate({ to: "/thank-you" });
    } catch (e: any) {
      toast.error("Could not submit", { description: e?.message });
    }
  }

  const progress = ((idx + 1) / INDICATIONS.length) * 100;

  return (
    <main className="min-h-screen bg-background">
      <div className="mx-auto max-w-6xl px-6 py-10">
        <header className="mb-8">
          <div className="mb-3 flex items-center justify-between text-sm text-muted-foreground">
            <span>Indication {idx + 1} of {INDICATIONS.length}</span>
            <span>{indicationsCovered} of {INDICATIONS.length} answered</span>
          </div>
          <Progress value={progress} className="h-1.5" />
          <div className="mt-6 flex items-end justify-between gap-4">
            <div>
              <p className="text-sm font-medium uppercase tracking-wider text-primary">Indication</p>
              <h1 className="mt-1 text-3xl font-semibold tracking-tight">{ind}</h1>
              <p className="mt-2 text-sm text-muted-foreground">
                Select your preferred implant configurations across the four systems.
              </p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => { clearIndication(ind!); toast.success("Cleared selections for this indication"); }}>
              <Eraser className="mr-2 h-4 w-4" /> Clear selections
            </Button>
          </div>
          <div className="mt-4"><PreferenceLegend /></div>
        </header>

        <SystemMatrices indication={ind} />

        <Card className="mt-8 p-6">
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="comment">Notes for this indication <span className="text-muted-foreground">(optional)</span></Label>
              <Textarea
                id="comment"
                rows={4}
                value={comments[ind] ?? ""}
                onChange={(e) => setComment(ind!, e.target.value)}
                placeholder="Anatomical preferences, surgical context…"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="suggest">
                If you could add one missing implant dimension for this indication, what would it be?
              </Label>
              <Textarea
                id="suggest"
                rows={4}
                value={suggestions[ind] ?? ""}
                onChange={(e) => setSuggestion(ind!, e.target.value)}
                placeholder="e.g. BLX Ø4.0 × 5 mm short"
              />
            </div>
          </div>
        </Card>

        <div className="mt-8 flex items-center justify-between">
          <Button variant="outline" onClick={goPrev} disabled={idx === 0}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Previous
          </Button>
          <Button onClick={goNext} size="lg">
            {isLast ? (<><CheckCircle2 className="mr-2 h-4 w-4" /> Submit questionnaire</>) : (<>Next indication <ArrowRight className="ml-2 h-4 w-4" /></>)}
          </Button>
        </div>
      </div>
    </main>
  );
}
